import os
import sys
import threading
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from runner import Runner  # noqa: E402


class Harness:
    def __init__(self):
        self.out = []
        self.finished = threading.Event()
        self.status = None
        self.prompts = []
        self.r = Runner(self.out.append, self._on_input, self._on_finish)

    def _on_input(self, prompt):
        self.prompts.append(prompt)
        self.r.provide_input("Əli")  # istifadəçi dərhal cavab verir

    def _on_finish(self, status, secs):
        self.status = status
        self.finished.set()

    def run(self, code, timeout=5):
        self.out.clear()
        self.finished.clear()
        self.r.start(code)
        assert self.finished.wait(timeout), "kod vaxtında bitmədi"
        time.sleep(0.01)
        return "".join(self.out)


class RunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.h = Harness()

    def test_print(self):
        self.assertEqual(self.h.run("print('salam', 1+1)"), "salam 2\n")
        self.assertEqual(self.h.status, "ok")

    def test_error_traceback_shows_user_line(self):
        out = self.h.run("x = 1\nprint(1/0)\n")
        self.assertEqual(self.h.status, "error")
        self.assertIn("ZeroDivisionError", out)
        self.assertIn("print(1/0)", out)
        self.assertNotIn("runner.py", out)

    def test_syntax_error(self):
        out = self.h.run("def f(:\n  pass")
        self.assertEqual(self.h.status, "error")
        self.assertIn("SyntaxError", out)

    def test_input(self):
        out = self.h.run("ad = input('Adın: ')\nprint('Salam,', ad)")
        self.assertEqual(out, "Adın: Əli\nSalam, Əli\n")
        self.assertEqual(self.h.prompts[-1], "Adın: ")

    def test_sys_exit_is_ok(self):
        self.h.run("import sys\nprint('a')\nsys.exit(0)\nprint('b')")
        self.assertEqual(self.h.status, "ok")

    def test_stop_busy_loop(self):
        self.h.out.clear()
        self.h.finished.clear()
        self.h.r.start("while True:\n    pass\n")
        time.sleep(0.2)
        self.assertTrue(self.h.r.running)
        self.h.r.stop()
        self.assertTrue(self.h.finished.wait(3))
        self.assertEqual(self.h.status, "stopped")

    def test_stop_while_waiting_for_input(self):
        h = Harness()
        h.r._on_input = None
        h.r.on_input = lambda p: None  # cavab verilmir
        h.finished.clear()
        h.r.start("input('?')")
        time.sleep(0.2)
        h.r.stop()
        self.assertTrue(h.finished.wait(3))
        self.assertEqual(h.status, "stopped")

    def test_second_run_blocked_while_running(self):
        self.h.finished.clear()
        self.h.r.start("import time\ntime.sleep(0.3)")
        self.assertFalse(self.h.r.start("print(1)"))
        self.assertTrue(self.h.finished.wait(3))

    def test_main_thread_print_not_captured(self):
        self.h.out.clear()
        print("main thread", file=sys.stdout)
        self.assertEqual(self.h.out, [])


if __name__ == "__main__":
    unittest.main()
