import hashlib
import io
import json
import os
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pkgman  # noqa: E402


def make_wheel(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, text in files.items():
            zf.writestr(name, text)
    return buf.getvalue()


class FakePyPI(pkgman.PackageManager):
    """Şəbəkəsiz test: PyPI cavablarını yaddaşdan verir."""

    def __init__(self, site, index):
        self.index = index
        super().__init__(site, log=lambda m: None)

    def _get(self, url):
        if url.startswith("https://files/"):
            return self.index["blobs"][url]
        name = url.split("/pypi/")[1].split("/")[0]
        if name not in self.index["pkgs"]:
            raise pkgman.PkgError("Belə paket PyPI-də tapılmadı.")
        return json.dumps(self.index["pkgs"][name]).encode()


def pkg_json(name, blob, requires=(), plat="any"):
    url = "https://files/%s.whl" % name
    return url, {
        "info": {"name": name, "version": "1.0", "summary": "test",
                 "requires_dist": list(requires)},
        "urls": [{"filename": "%s-1.0-py3-none-%s.whl" % (name, plat), "url": url,
                  "digests": {"sha256": hashlib.sha256(blob).hexdigest()}}],
    }


class PkgTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        a = make_wheel({"liba/__init__.py": "X = 1\n", "liba-1.0.dist-info/METADATA": "m"})
        b = make_wheel({"libb.py": "Y = 2\n", "libb-1.0.dist-info/METADATA": "m"})
        ua, ja = pkg_json("liba", a, requires=["libb (>=1)", "winonly ; sys_platform == 'win32'",
                                              "extra-dep ; extra == 'x'"])
        ub, jb = pkg_json("libb", b)
        c = make_wheel({"../evil.py": "boom"})
        uc, jc = pkg_json("evil", c)
        uv, jv = pkg_json("cext", b, plat="manylinux1_x86_64")
        jv["urls"][0]["filename"] = "cext-1.0-cp312-cp312-linux_x86_64.whl"
        self.index = {"blobs": {ua: a, ub: b, uc: c},
                      "pkgs": {"liba": ja, "libb": jb, "evil": jc, "cext": jv}}
        self.pm = FakePyPI(self.tmp, self.index)

    def test_install_with_dependency_and_skip_markers(self):
        done = self.pm.install("LibA")
        self.assertEqual(done, ["libb", "liba"])
        self.assertTrue(os.path.exists(os.path.join(self.tmp, "liba", "__init__.py")))
        self.assertTrue(os.path.exists(os.path.join(self.tmp, "libb.py")))
        self.assertEqual([n for n, _ in self.pm.installed()], ["liba", "libb"])

    def test_reinstall_is_noop(self):
        self.pm.install("libb")
        self.assertEqual(self.pm.install("libb"), [])

    def test_remove(self):
        self.pm.install("liba")
        self.pm.remove("liba")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "liba")))
        self.assertTrue(os.path.exists(os.path.join(self.tmp, "libb.py")))
        self.assertFalse(self.pm.is_installed("liba"))

    def test_remove_missing(self):
        with self.assertRaises(pkgman.PkgError):
            self.pm.remove("nope")

    def test_c_extension_rejected(self):
        with self.assertRaises(pkgman.PkgError) as ctx:
            self.pm.install("cext")
        self.assertIn("C kodlu", str(ctx.exception))

    def test_path_traversal_blocked(self):
        with self.assertRaises(pkgman.PkgError):
            self.pm.install("evil")
        self.assertFalse(os.path.exists(os.path.join(self.tmp, "..", "evil.py")))

    def test_unknown_package(self):
        with self.assertRaises(pkgman.PkgError):
            self.pm.install("zzz")

    def test_importable_after_install(self):
        self.pm.install("liba")
        import importlib
        mod = importlib.import_module("liba")
        self.assertEqual(mod.X, 1)


if __name__ == "__main__":
    unittest.main()
